package Pets;

import java.util.List;

public class Newpet_Requestbody {
	

	private int id;
	Category category;
	private String name;
	private List<String> photoUrls;
	List<Tags> tags;
	private String status;
	
	public Newpet_Requestbody(int id, Category category, String name, List<String> photoUrls, List<Tags> tags,
			String status) {
		super();
		this.id = id;
		this.category = category;
		this.name = name;
		this.photoUrls = photoUrls;
		this.tags = tags;
		this.status = status;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the category
	 */
	public Category getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(Category category) {
		this.category = category;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the photoUrls
	 */
	public List<String> getPhotoUrls() {
		return photoUrls;
	}

	/**
	 * @param photoUrls the photoUrls to set
	 */
	public void setPhotoUrls(List<String> photoUrls) {
		this.photoUrls = photoUrls;
	}

	/**
	 * @return the tags
	 */
	public List<Tags> getTags() {
		return tags;
	}

	/**
	 * @param tags the tags to set
	 */
	public void setTags(List<Tags> tags) {
		this.tags = tags;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Newpet_Requestbody [id=" + id + ", category=" + category + ", name=" + name + ", photoUrls=" + photoUrls
				+ ", tags=" + tags + ", status=" + status + "]";
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	
	
	
	
	
	
}
