package com.restAssured;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import Pets.Category;
import Pets.Newpet_Requestbody;
import Pets.Tags;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AddNewPetUsingPojoTest {
	
	Newpet_Requestbody newPetRequestBody;
    

    

    @Test
    public void createBookingIdUsingPOJO() {

    	Category category=new Category(123,"TestCategory");
    	Tags tag1=new Tags( 999,"Tag1");
    	Tags tag2=new Tags( 989,"Tag2");
    	List<Tags> tags = new ArrayList<>();
    	tags.add(tag1);
    	tags.add(tag2);
    	
    	List<String> photoUrls=new ArrayList<String>();
    	photoUrls.add("Test");
    	photoUrls.add("Test");
    	
    	newPetRequestBody=new Newpet_Requestbody(112, category, "doggie", photoUrls, tags, "available");
        
               
        RequestSpecification request = given()
                .contentType(ContentType.JSON)
                .body(newPetRequestBody);
        System.out.println("Request body: ");
        request.log().all();

        Response response = request
                .when()
                .post("https://petstore.swagger.io/v2/pet");

        System.out.println("Response body: ");
        response.prettyPrint();

//                Verify response status code 200
        Assert.assertEquals("Status code should be 200", response.getStatusCode(), 200);

        //        Soft Assert all fields
        SoftAssertions softAssert = new SoftAssertions();

        JsonPath jsonPath = response.jsonPath();
        softAssert.assertThat(jsonPath.getInt("id")).
                as("ID is not matching").
                isEqualTo(newPetRequestBody.getId());
        

        softAssert.assertThat(jsonPath.getInt("category.id")).
        as("Category ID is not matching").
        isEqualTo(category.getId());
      
        softAssert.assertThat(jsonPath.getString("category.name")).
        as("Category name is not matching").
        isEqualTo(category.getName());
        
        softAssert.assertThat(jsonPath.getString("name")).
        as("name is not matching").
        isEqualTo(newPetRequestBody.getName());
        
        softAssert.assertThat(jsonPath.getList("photoUrls")).
        as("photoUrls are not matching").
        isEqualTo(newPetRequestBody.getPhotoUrls());
        
        softAssert.assertThat(jsonPath.getString("category.name")).
        as("Category name is not matching").
        isEqualTo(category.getName());
        
        softAssert.assertThat(jsonPath.getString("status")).
        as("status is not matching").
        isEqualTo(newPetRequestBody.getStatus());
        softAssert.assertAll();
        System.out.println("Soft assertion for create Pet is successful");
    }

}
